#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
證候文本批次轉換腳本
將原始文本轉換為標準化 JSON 格式
"""

import re
import json
from pathlib import Path
from pypinyin import pinyin, Style

# 證素對應表（簡化版，用於自動匹配）
ZHENGSU_MAPPING = {
    # 病性證素
    "氣虛": "qi_xu",
    "氣陷": "qi_xian",
    "氣脫": "qi_tuo",
    "氣滯": "qi_zhi",
    "氣逆": "qi_ni",
    "氣閉": "qi_bi",
    "血虛": "xue_xu",
    "血脫": "xue_tuo",
    "血瘀": "xue_yu",
    "血熱": "xue_re",
    "血燥": "xue_zao",
    "血寒": "xue_han",
    "精脫": "jing_tuo",
    "陰虛": "yin_xu",
    "津虧": "jin_kui",
    "陽虛": "yang_xu",
    "亡陰": "wang_yin",
    "亡陽": "wang_yang",
    "失神": "shi_shen",
    "風": "feng",
    "寒": "han",
    "暑": "shu",
    "濕": "shi",
    "燥": "zao",
    "火熱": "huo_re",
    "痰": "tan",
    "毒": "du",
    "動風": "dong_feng",
    "動血": "dong_xue",
    "化火": "hua_huo",
    "化熱": "hua_re",
    "水停": "shui_ting",
    "生風": "sheng_feng",
    "風燥": "feng_zao",
    "寒凝": "han_ning",
    "外感": "wai_gan",
    "痰凝": "tan_ning",
    "濕阻": "shi_zu",
    "痺阻": "bi_zu",
}

# 病位證素
LOCATION_MAPPING = {
    "心": "xin",
    "肝": "gan",
    "脾": "pi",
    "肺": "fei",
    "腎": "shen",
    "胃": "wei",
    "膽": "dan",
    "太陽": "taiyang",
    "陽明": "yangming",
    "少陽": "shaoyang",
    "太陰": "taiyin",
    "厥陰": "jueyin",
    "少陰": "shaoyin",
    "衛分": "weifen",
    "氣分": "qifen",
    "營分": "yingfen",
    "血分": "xuefen",
}

# 證型分類
CATEGORY_MAP = {
    range(1, 28): "基礎證候",
    range(28, 34): "六經辨證",
    range(34, 38): "衛氣營血辨證",
    range(38, 57): "複合證候",
}

def get_category(index):
    for r, cat in CATEGORY_MAP.items():
        if index in r:
            return cat
    return "其他"

def name_to_id(name):
    """將證型名稱轉換為拼音ID"""
    # 移除「證」字
    name = name.replace("證", "")
    try:
        py = pinyin(name, style=Style.NORMAL)
        return "_".join([p[0] for p in py])
    except:
        return name.lower()

def extract_sections(content):
    """提取證型內容各段落"""
    sections = {}
    
    # 概述
    overview_match = re.search(r'【概述】\n(.*?)(?=【鑑別】|$)', content, re.DOTALL)
    if overview_match:
        sections['overview'] = overview_match.group(1).strip()
    
    # 鑑別 - 本證辨析
    benzheng_match = re.search(r'本證辨析\n(.*?)(?=類證鑑別|【文獻選錄】|$)', content, re.DOTALL)
    if benzheng_match:
        sections['self_analysis'] = benzheng_match.group(1).strip()
    
    # 鑑別 - 類證鑑別
    leibie_match = re.search(r'類證鑑別\n(.*?)(?=【文獻選錄】|$)', content, re.DOTALL)
    if leibie_match:
        sections['differential'] = leibie_match.group(1).strip()
    
    # 文獻選錄
    lit_match = re.search(r'【文獻選錄】\n(.*?)$', content, re.DOTALL)
    if lit_match:
        sections['literature'] = lit_match.group(1).strip()
    
    return sections

def extract_clinical_manifestations(overview):
    """提取臨床表現"""
    pattern = r'主要臨床表現[為是：:]+[：:]?(.*?)(?=\n[^\n]*證[常散]見於|$)'
    match = re.search(pattern, overview, re.DOTALL)
    if match:
        text = match.group(1).strip()
        # 清理多餘換行
        text = re.sub(r'\n+', '', text)
        return text
    return ""

def extract_diseases(overview):
    """提取常見病證"""
    pattern = r'[常散]見於[「「]?(.*?)[」」]?等[疾病變]'
    match = re.search(pattern, overview)
    if match:
        diseases = match.group(1)
        # 分割並清理
        items = re.split(r'[、」「]', diseases)
        return [d.strip().strip('「」""') for d in items if d.strip()]
    return []

def extract_differential_patterns(overview):
    """提取需鑑別證型"""
    pattern = r'應[當與]+[「「]?(.*?)[」」]?相鑑別'
    match = re.search(pattern, overview)
    if match:
        patterns = match.group(1)
        items = re.split(r'[、」「]', patterns)
        return [p.strip().strip('「」""') for p in items if p.strip()]
    return []

def extract_pathogenesis(overview):
    """提取病機"""
    patterns = [
        r'多[因由](.*?)所致',
        r'本證[多常]為(.*?)所致',
        r'[因由]於(.*?)[，,。]',
    ]
    for pattern in patterns:
        match = re.search(pattern, overview)
        if match:
            return match.group(1).strip()
    return ""

def parse_symptoms(manifestations):
    """解析症狀，分離舌脈"""
    result = {
        "primary": [],
        "secondary": [],
        "tongue": "",
        "pulse": ""
    }
    
    if not manifestations:
        return result
    
    # 提取舌象
    tongue_match = re.search(r'舌[質色]?[淡紅絳暗紫白胖瘦嫩老]+[，,]?[苔薄厚白黃膩滑燥少剝光]*', manifestations)
    if tongue_match:
        result["tongue"] = tongue_match.group(0).strip('，,')
    
    # 提取脈象
    pulse_match = re.search(r'脈[沉浮遲數細洪滑澀弦緊微弱虛實芤革牢促結代短長]+[無力有力]*', manifestations)
    if pulse_match:
        result["pulse"] = pulse_match.group(0)
    
    # 提取其他症狀
    # 移除舌脈描述後分割
    symptoms_text = manifestations
    if result["tongue"]:
        symptoms_text = symptoms_text.replace(result["tongue"], "")
    if result["pulse"]:
        symptoms_text = symptoms_text.replace(result["pulse"], "")
    
    # 分割症狀
    symptoms = re.split(r'[，,、；;。]', symptoms_text)
    symptoms = [s.strip() for s in symptoms if s.strip() and len(s) > 1]
    
    # 前4個為主症，其餘為次症
    result["primary"] = symptoms[:4] if len(symptoms) >= 4 else symptoms
    result["secondary"] = symptoms[4:] if len(symptoms) > 4 else []
    
    return result

def infer_zhengsu(name):
    """從證型名稱推斷證素組合"""
    location = []
    nature = []
    
    # 檢查病位
    for loc_name, loc_id in LOCATION_MAPPING.items():
        if loc_name in name:
            location.append(loc_id)
    
    # 檢查病性
    for nat_name, nat_id in ZHENGSU_MAPPING.items():
        if nat_name in name:
            nature.append(nat_id)
    
    return {"location": location, "nature": nature}

def infer_severity(name, category):
    """推斷嚴重程度"""
    if "脫" in name or "亡" in name or "厥" in name:
        return 4
    if "閉" in name or "逆" in name:
        return 3
    if "滯" in name or "瘀" in name or "陷" in name:
        return 2
    if "虛" in name or category == "基礎證候":
        return 1
    return 2

def convert_syndrome(index, name, content):
    """轉換單個證型"""
    sections = extract_sections(content)
    overview = sections.get('overview', '')
    
    manifestations = extract_clinical_manifestations(overview)
    symptoms = parse_symptoms(manifestations)
    category = get_category(index)
    
    syndrome = {
        "id": name_to_id(name),
        "name": name,
        "category": category,
        "index": index,
        "zhengsu_composition": infer_zhengsu(name),
        "severity": infer_severity(name, category),
        "symptoms": symptoms,
        "clinical_manifestations": manifestations,
        "pathogenesis": extract_pathogenesis(overview),
        "common_diseases": extract_diseases(overview),
        "differential_patterns": extract_differential_patterns(overview),
        "self_analysis": sections.get('self_analysis', ''),
        "differential_analysis": sections.get('differential', ''),
        "literature": sections.get('literature', ''),
    }
    
    return syndrome

def main():
    # 讀取原始文本
    filepath = Path('/home/claude/tcm-project/#U4e2d#U91ab#U8b49#U5019#U7d14#U6587#U5b57#U6a94.md')
    with open(filepath, 'r', encoding='utf-8') as f:
        text = f.read()
    
    # 匹配所有證型
    pattern = r'^(\d+)\.(.+證)\n'
    matches = list(re.finditer(pattern, text, re.MULTILINE))
    
    output_dir = Path('/home/claude/tcm-project/data/zhengxing_new')
    output_dir.mkdir(exist_ok=True)
    
    syndromes = []
    
    for i, match in enumerate(matches):
        num = int(match.group(1))
        name = match.group(2).strip()
        start = match.start()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        content = text[start:end].strip()
        
        syndrome = convert_syndrome(num, name, content)
        syndromes.append(syndrome)
        
        # 保存單個檔案
        filename = f"{syndrome['id']}.json"
        with open(output_dir / filename, 'w', encoding='utf-8') as f:
            json.dump(syndrome, f, ensure_ascii=False, indent=2)
        
        print(f"✅ {num:2d}. {name} → {filename}")
    
    # 保存索引
    index_data = {
        "total": len(syndromes),
        "syndromes": [{"id": s["id"], "name": s["name"], "category": s["category"]} for s in syndromes]
    }
    with open(output_dir / "_index.json", 'w', encoding='utf-8') as f:
        json.dump(index_data, f, ensure_ascii=False, indent=2)
    
    print(f"\n✅ 共轉換 {len(syndromes)} 個證型")
    print(f"📁 輸出目錄: {output_dir}")

if __name__ == '__main__':
    main()
