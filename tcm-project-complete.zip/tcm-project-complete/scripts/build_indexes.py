#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
建立索引檔案
1. symptom_index.json — 症狀反查
2. evolution_graph.json — 演變圖譜
3. differentiation_matrix.json — 鑑別矩陣
"""

import json
from pathlib import Path
from collections import defaultdict

def load_syndromes(data_dir):
    """載入所有證型"""
    syndromes = {}
    for f in data_dir.glob("*.json"):
        if f.name.startswith("_"):
            continue
        with open(f, 'r', encoding='utf-8') as file:
            data = json.load(file)
            syndromes[data['id']] = data
    return syndromes

def build_symptom_index(syndromes):
    """建立症狀反查索引"""
    index = defaultdict(list)
    
    for syn_id, syn in syndromes.items():
        symptoms = syn.get('symptoms', {})
        all_symptoms = (
            symptoms.get('primary', []) + 
            symptoms.get('secondary', [])
        )
        
        # 添加舌脈
        if symptoms.get('tongue'):
            all_symptoms.append(symptoms['tongue'])
        if symptoms.get('pulse'):
            all_symptoms.append(symptoms['pulse'])
        
        for symptom in all_symptoms:
            # 清理症狀文字
            symptom = symptom.strip().strip('，,。、')
            if len(symptom) < 2 or symptom.startswith('或') or symptom.startswith('等'):
                continue
            
            # 提取關鍵詞
            keywords = extract_keywords(symptom)
            for kw in keywords:
                if kw not in index[kw]:
                    index[kw].append({
                        "syndrome_id": syn_id,
                        "syndrome_name": syn['name'],
                        "symptom": symptom
                    })
    
    return dict(index)

def extract_keywords(symptom):
    """從症狀提取關鍵詞"""
    keywords = []
    
    # 直接使用整個症狀作為關鍵詞
    if len(symptom) <= 6:
        keywords.append(symptom)
    
    # 提取常見症狀詞
    common_symptoms = [
        "乏力", "氣短", "心悸", "失眠", "頭暈", "眩暈", "耳鳴",
        "自汗", "盜汗", "潮熱", "發熱", "惡寒", "畏寒",
        "口渴", "口乾", "口苦", "咽乾", "咽痛",
        "咳嗽", "喘息", "氣喘", "痰多",
        "胸悶", "胸痛", "心痛", "脅痛", "腹痛", "腰痛",
        "腹脹", "脘腹", "嘔吐", "納呆", "便秘", "便溏", "洩瀉",
        "水腫", "尿少", "尿頻", "遺精",
        "麻木", "抽搐", "痙攣", "震顫",
        "面白", "面黃", "面紅", "唇紫",
        "舌淡", "舌紅", "舌絳", "舌紫", "苔白", "苔黃", "苔膩",
        "脈沉", "脈浮", "脈細", "脈數", "脈弦", "脈滑", "脈澀",
        "神疲", "精神", "煩躁", "譫語", "昏迷",
        "月經", "經閉", "痛經", "崩漏",
    ]
    
    for s in common_symptoms:
        if s in symptom:
            keywords.append(s)
    
    return list(set(keywords))

def build_evolution_graph(syndromes):
    """建立演變關係圖"""
    nodes = []
    edges = []
    
    # 建立節點
    for syn_id, syn in syndromes.items():
        nodes.append({
            "id": syn_id,
            "name": syn['name'],
            "category": syn.get('category', ''),
            "severity": syn.get('severity', 1)
        })
    
    # 分析演變關係
    evolution_patterns = {
        # 氣病演變
        "qi_xu": ["qi_xian", "yang_xu", "qi_xu_xue_yu"],
        "qi_xian": ["qi_tuo"],
        "qi_tuo": ["wang_yang"],
        "qi_zhi": ["qi_ni", "qi_zhi_xue_yu", "qi_zhi_tan_ning"],
        "qi_ni": ["qi_bi"],
        
        # 血病演變
        "xue_xu": ["xue_tuo", "xue_xu_sheng_feng", "xue_xu_feng_zao"],
        "xue_re": ["xue_yu", "xue_re_dong_feng"],
        "xue_han": ["xue_yu"],
        "xue_yu": ["xue_yu_hua_re", "xue_yu_dong_xue"],
        
        # 陰陽演變
        "yin_xu": ["yin_xu_jin_kui", "wang_yin"],
        "yang_xu": ["wang_yang"],
        "wang_yin": ["wang_yang"],
    }
    
    for source, targets in evolution_patterns.items():
        for target in targets:
            if source in syndromes and target in syndromes:
                edges.append({
                    "source": source,
                    "target": target,
                    "type": "evolution"
                })
    
    return {"nodes": nodes, "edges": edges}

def build_differentiation_matrix(syndromes):
    """建立鑑別矩陣"""
    matrix = {}
    
    for syn_id, syn in syndromes.items():
        diff_patterns = syn.get('differential_patterns', [])
        if diff_patterns:
            matrix[syn_id] = {
                "name": syn['name'],
                "differentials": []
            }
            for pattern in diff_patterns:
                # 清理引號
                pattern = pattern.strip().strip('「」""')
                matrix[syn_id]["differentials"].append(pattern)
    
    return matrix

def main():
    data_dir = Path('/home/claude/tcm-project/data/zhengxing_new')
    index_dir = Path('/home/claude/tcm-project/data/indexes')
    index_dir.mkdir(exist_ok=True)
    
    print("載入證型資料...")
    syndromes = load_syndromes(data_dir)
    print(f"已載入 {len(syndromes)} 個證型")
    
    # 建立症狀索引
    print("\n建立症狀反查索引...")
    symptom_index = build_symptom_index(syndromes)
    with open(index_dir / 'symptom_index.json', 'w', encoding='utf-8') as f:
        json.dump(symptom_index, f, ensure_ascii=False, indent=2)
    print(f"✅ 症狀索引: {len(symptom_index)} 個關鍵詞")
    
    # 建立演變圖譜
    print("\n建立演變圖譜...")
    evolution = build_evolution_graph(syndromes)
    with open(index_dir / 'evolution_graph.json', 'w', encoding='utf-8') as f:
        json.dump(evolution, f, ensure_ascii=False, indent=2)
    print(f"✅ 演變圖譜: {len(evolution['nodes'])} 節點, {len(evolution['edges'])} 邊")
    
    # 建立鑑別矩陣
    print("\n建立鑑別矩陣...")
    diff_matrix = build_differentiation_matrix(syndromes)
    with open(index_dir / 'differentiation_matrix.json', 'w', encoding='utf-8') as f:
        json.dump(diff_matrix, f, ensure_ascii=False, indent=2)
    print(f"✅ 鑑別矩陣: {len(diff_matrix)} 個證型有鑑別資料")
    
    print(f"\n📁 索引目錄: {index_dir}")

if __name__ == '__main__':
    main()
