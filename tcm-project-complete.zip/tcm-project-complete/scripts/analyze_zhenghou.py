#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
證候文本預處理分析腳本
階段一：自動切分、產出總覽表、識別關係
"""

import re
import json
from pathlib import Path

def load_text(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        return f.read()

def extract_syndromes(text):
    """提取所有證型及其內容"""
    # 匹配格式：數字.證型名
    pattern = r'^(\d+)\.(.+證)\n'
    matches = list(re.finditer(pattern, text, re.MULTILINE))
    
    syndromes = []
    for i, match in enumerate(matches):
        num = match.group(1)
        name = match.group(2).strip()
        start = match.start()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        content = text[start:end].strip()
        
        # 提取各個段落
        sections = extract_sections(content)
        
        syndromes.append({
            'index': int(num),
            'name': name,
            'start_line': text[:start].count('\n') + 1,
            'sections': sections,
            'content_length': len(content)
        })
    
    return syndromes

def extract_sections(content):
    """提取證型內的各個段落"""
    sections = {}
    
    # 概述
    overview_match = re.search(r'【概述】\n(.*?)(?=【鑑別】|$)', content, re.DOTALL)
    if overview_match:
        sections['overview'] = overview_match.group(1).strip()
    
    # 鑑別
    diff_match = re.search(r'【鑑別】\n(.*?)(?=【文獻選錄】|$)', content, re.DOTALL)
    if diff_match:
        sections['differentiation'] = diff_match.group(1).strip()
    
    # 文獻選錄
    lit_match = re.search(r'【文獻選錄】\n(.*?)$', content, re.DOTALL)
    if lit_match:
        sections['literature'] = lit_match.group(1).strip()
    
    return sections

def extract_clinical_manifestations(overview):
    """從概述中提取臨床表現"""
    pattern = r'主要臨床表現[為是：]+(.*?)(?=\n|$)'
    match = re.search(pattern, overview)
    if match:
        return match.group(1).strip()
    return None

def extract_related_diseases(overview):
    """提取相關病證"""
    pattern = r'常見於[「「]?(.*?)[」」]?等疾病中'
    match = re.search(pattern, overview)
    if match:
        diseases = match.group(1)
        return [d.strip() for d in re.split(r'[、」「]', diseases) if d.strip()]
    return []

def extract_differential_syndromes(overview):
    """提取需鑑別的證型"""
    pattern = r'應[當與]+(.*?)相鑑別'
    match = re.search(pattern, overview)
    if match:
        syndromes = match.group(1)
        return [s.strip().strip('「」「」') for s in re.split(r'[、」「]', syndromes) if s.strip()]
    return []

def identify_evolution_relations(syndromes):
    """識別證型演變關係"""
    evolution_patterns = [
        (r'可為(.+?)的前[奏驅]', 'precursor_of'),
        (r'由(.+?)發展而來', 'evolved_from'),
        (r'可發展[為成](.+?)證', 'can_evolve_to'),
        (r'進一步發展.*?出現(.+?)證', 'can_evolve_to'),
        (r'演[化變]為(.+?)證', 'can_evolve_to'),
    ]
    
    relations = []
    for syn in syndromes:
        content = syn['sections'].get('overview', '') + syn['sections'].get('differentiation', '')
        for pattern, rel_type in evolution_patterns:
            matches = re.findall(pattern, content)
            for match in matches:
                relations.append({
                    'from': syn['name'],
                    'to': match.strip(),
                    'type': rel_type
                })
    
    return relations

def generate_summary(syndromes):
    """生成證型總覽表"""
    summary = []
    for syn in syndromes:
        overview = syn['sections'].get('overview', '')
        
        entry = {
            'index': syn['index'],
            'name': syn['name'],
            'clinical_manifestations': extract_clinical_manifestations(overview),
            'related_diseases': extract_related_diseases(overview),
            'differential_syndromes': extract_differential_syndromes(overview),
            'has_literature': 'literature' in syn['sections'],
            'content_length': syn['content_length']
        }
        summary.append(entry)
    
    return summary

def main():
    filepath = Path('/home/claude/tcm-project/#U4e2d#U91ab#U8b49#U5019#U7d14#U6587#U5b57#U6a94.md')
    text = load_text(filepath)
    
    print("=" * 60)
    print("中醫證候文本預處理分析報告")
    print("=" * 60)
    
    # 提取證型
    syndromes = extract_syndromes(text)
    print(f"\n📊 共識別 {len(syndromes)} 個證型\n")
    
    # 生成總覽
    summary = generate_summary(syndromes)
    
    # 輸出總覽表
    print("=" * 60)
    print("證型總覽表")
    print("=" * 60)
    
    for s in summary:
        print(f"\n{s['index']:2d}. {s['name']}")
        if s['clinical_manifestations']:
            manifestation = s['clinical_manifestations'][:80]
            if len(s['clinical_manifestations']) > 80:
                manifestation += '...'
            print(f"    臨床表現: {manifestation}")
        if s['differential_syndromes']:
            print(f"    需鑑別: {', '.join(s['differential_syndromes'][:5])}")
    
    # 識別演變關係
    relations = identify_evolution_relations(syndromes)
    print("\n" + "=" * 60)
    print("證型演變關係（部分）")
    print("=" * 60)
    for rel in relations[:20]:
        print(f"  {rel['from']} → {rel['to']} ({rel['type']})")
    
    # 統計
    print("\n" + "=" * 60)
    print("統計數據")
    print("=" * 60)
    
    total_length = sum(s['content_length'] for s in summary)
    avg_length = total_length // len(summary)
    
    print(f"  總字數: {total_length:,}")
    print(f"  平均每證型字數: {avg_length:,}")
    print(f"  有文獻選錄: {sum(1 for s in summary if s['has_literature'])}")
    
    # 輸出 JSON
    output_path = Path('/home/claude/tcm-project/data/analysis_result.json')
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump({
            'total_syndromes': len(syndromes),
            'summary': summary,
            'evolution_relations': relations
        }, f, ensure_ascii=False, indent=2)
    
    print(f"\n✅ 分析結果已保存至: {output_path}")

if __name__ == '__main__':
    main()
