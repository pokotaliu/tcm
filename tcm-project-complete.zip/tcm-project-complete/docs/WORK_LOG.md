# TCM 中醫證候資料庫 - 工作日誌

> 最後更新：2025-12-05
> 用途：供 Claude 在新對話中快速理解專案狀態與待辦事項

---

## 一、專案概述

### 目標
建立一個中醫證候知識庫，同時支援：
1. **Obsidian Vault** — 個人學習與知識管理
2. **Web App** — 互動式證候查詢網站（GitHub Pages）

### 四大核心功能
| 功能 | 說明 | 狀態 |
|------|------|------|
| A. 並列對比 | 選擇多個證型並排比較 | 規劃中 |
| B. 互動式演變圖 | 可點擊展開的證型演變圖 | 規劃中 |
| C. 證素篩選器 | 按病位/病性組合篩選 | 基礎版已有 |
| D. 症狀反查 | 輸入症狀，顯示相關證型 | 規劃中 |

---

## 二、證素系統設計

### 核心概念

**證素是證型的原子單位**。每個證型由「病位證素 + 病性證素」組合而成。

```
證型 = 病位證素 + 病性證素
例：脾氣虛證 = 脾（病位）+ 氣虛（病性）
例：中氣下陷證 = 脾（病位）+ 氣虛 + 氣陷（病性）
```

### 證素分類架構

#### 病位證素（19個）

| 子類 | 證素 |
|------|------|
| **五臟** | 心(xin)、肝(gan)、脾(pi)、肺(fei)、腎(shen) |
| **六腑** | 胃(wei)、膽(dan)、小腸(xiaochang)、大腸(dachang)、膀胱(pangguang) |
| **特殊** | 胞宮(baogong)、精室(jingshi) |
| **部位** | 胸膈(xiongge)、少腹(shaofu) |
| **表裡** | 表(biao)、半表半裡(banbiaobanli) |
| **形體** | 肌膚(jifu)、經絡(jingluo)、筋骨(jingu) |

#### 病性證素（36個）+ 對應治法

| 子類 | 證素 → 治法 |
|------|-------------|
| **氣機病變** | 氣虛→補氣、氣滯→行氣、氣逆→降氣、氣陷→升提、氣閉→開閉、氣脫→固脫、不固→收攝、清陽不升→升清降濁、氣厥→開鬱醒神 |
| **血液病變** | 血虛→補血、血瘀→活血、血熱→涼血、血寒→溫經、動血→止血 |
| **陰陽病變** | 陰虛→滋陰、陽虛→溫陽、陽亢→平肝潛陽、陽浮→引火歸元、亡陰→救陰、亡陽→回陽 |
| **外邪** | 風→祛風、寒→散寒、暑→清暑、濕→化濕、燥→潤燥、火→瀉火、毒→解毒 |
| **病理產物** | 痰→化痰、飲→化飲、水停→利水、食積→消食、蟲積→驅蟲、膿→排膿 |
| **精津病變** | 津虧→生津、精虧→填精 |
| **內生病邪** | 動風→熄風 |

### 證素 → 證型 對應邏輯

```
1. 單一病性 + 無特定病位 = 基礎證型
   氣虛 → 氣虛證
   
2. 單一病性 + 特定病位 = 臟腑證型
   脾 + 氣虛 → 脾氣虛證
   腎 + 陽虛 → 腎陽虛證
   
3. 多個病性 + 病位 = 複合證型
   脾 + 氣虛 + 氣陷 → 中氣下陷證
   肝 + 陰虛 + 陽亢 → 肝陰虛陽亢證
   
4. 證型演變關係
   氣虛 → 氣陷 → 氣脫 → 亡陽（病性層層加重）
```

### 證素 ID 命名規則

- 病位：單字拼音（如 `pi`, `gan`, `shen`）
- 病性：拼音加下劃線分隔（如 `qi_xu`, `xue_yu`, `yang_xu`）
- 複合病性：完整拼音（如 `qingyang_busheng`）

### 證素與治法的自動推導

根據證素組合，可自動推導治法：

```python
def derive_treatment(zhengsu_list):
    treatments = []
    for zs in zhengsu_list:
        if zs.treatment:
            treatments.append(zs.treatment)
    return treatments

# 例：中氣下陷證
# 證素：[pi, qi_xu, qi_xian]
# 推導治法：[補氣, 升提] → 補氣升陽
```

### 證素檔案結構

位於 `data/zhengsu/*.json`：

```json
{
  "id": "qi_xu",
  "name": "氣虛",
  "category": "病性",
  "subcategory": "氣機病變",
  "treatment": "補氣",
  "is_critical": false,
  "alias": ["氣弱", "中氣不足", "元氣虧虛"],
  "description": "氣虛是指人體元氣不足，臟腑功能活動減退的病理狀態。",
  "related_symptoms": ["symptom_fali", "symptom_qiduan", "symptom_zihan"]
}
```

---

## 三、現有資料結構

```
tcm-main/
├── data/
│   ├── zhengsu/         # 證素（55個）- 病位+病性的原子單位
│   ├── zhengxing/       # 證型（19個）- 證素組合成的完整證型
│   ├── zhenghou/        # 證候（56個）- 原始證候資料
│   │   └── syndromes/   
│   ├── herbs/           # 中藥（4個）
│   ├── formulas/        # 方劑（4個）
│   ├── symptoms/        # 症狀（10個）
│   └── diseases/        # 病證（1個）
├── css/style.css
├── js/zhenghou.js
├── index.html
└── docs/
    ├── STRUCTURE.md
    ├── TODO.md
    └── CHANGELOG.md
```

### 證型資料欄位完整度
```
✅ 100%：id, name, alias, zhengsu_composition, symptoms, treatment_principle, recommended_formulas
⚠️ 74%：evolved_from
⚠️ 84%：can_evolve_to  
⚠️ 63%：differentiation, pathogenesis, common_in
❌ 0%：severity（需新增）
```

---

## 四、已確定的資料結構

### Obsidian 證型模板（Web-Ready 版）

```yaml
---
# ===== 基本資訊 =====
id: yinxu                          # 拼音 ID（必填）
name: 陰虛證                        # 證型名稱（必填）
category: 基礎證候                  # 分類（必填）

# ===== 證素組成 =====
zhengsu:
  location: []                      # 病位 ID，如 ["pi", "shen"]
  nature: ["yin_xu"]                # 病性 ID

# ===== 嚴重程度 =====
severity: 1                         # 1=輕 2=中 3=重 4=危

# ===== 演變關係 =====
evolved_from: []                    # 由哪些證型演變而來
can_evolve_to:                      # 可演變為哪些證型
  - yinxu_huowang
  - wangyin

# ===== 類證鑑別 =====
similar_patterns:                   # 易混淆的證型
  - id: xuexu
    name: 血虛證
    key_diff: 陰虛有熱象，血虛無明顯熱象

# ===== 症狀關鍵字 =====
symptoms_keywords:
  - 潮熱盜汗
  - 五心煩熱
  - 舌紅少苔
  - 脈細數

# ===== 分組標籤 =====
comparison_tags:
  - 陰陽系列
  - 虛證

# ===== Obsidian 專用 =====
aliases: [陰虛]
tags: [證型, 基礎證候, 陰虛]
---
```

### Severity 分級標準
| 等級 | 判定依據 | 代表證型 |
|------|----------|----------|
| 1 輕 | 基礎虛證 | 氣虛、血虛、陰虛、陽虛 |
| 2 中 | 進展證 | 氣陷、氣滯、血瘀、清陽不升 |
| 3 重 | 危重前驅 | 氣逆、氣閉、血脫 |
| 4 危 | 脫證 | 氣脫、亡陰、亡陽 |

---

## 五、規劃中的索引檔案

待建立於 `data/indexes/` 目錄：

| 檔案 | 用途 |
|------|------|
| `symptom_index.json` | 症狀 → 證型的反向索引 |
| `evolution_graph.json` | 演變關係的有向圖結構 |
| `differentiation_matrix.json` | 類證鑑別的關係矩陣 |
| `zhengsu_mapping.json` | 證素 ↔ 證型的雙向對應 |

---

## 六、待執行工作

### 第一階段：資料層增強
- [ ] 建立 `data/indexes/` 目錄結構
- [ ] 補充所有證型的 `evolved_from` / `can_evolve_to`
- [ ] 新增所有證型的 `severity` 欄位
- [ ] 提取 `symptom_keywords`
- [ ] 建立索引生成腳本

### 第二階段：批次處理原始文檔
用戶有一份完整的中醫證候文本（未經校正），包含所有證型。

**建議處理流程：**
1. 上傳完整文檔
2. 自動切分為個別證型
3. 建立證型清單與初步索引
4. 識別全局模式（演變關係、鑑別組）
5. OCR 錯誤批次檢測
6. 按分類批次處理
7. 人工校驗
8. 輸出 Obsidian + JSON

**需先確認：**
- 文檔大小（評估是否需分批）
- 每個證型之間如何分隔
- 內容結構（固定段落）

### 第三階段：Web App 功能開發
- [ ] 並列對比頁面
- [ ] 互動式演變圖（D3.js 或 Cytoscape.js）
- [ ] 增強篩選器（多條件組合）
- [ ] 症狀反查入口

---

## 七、重要參考檔案

| 檔案 | 說明 |
|------|------|
| `data/zhengxing/_schema_extended.json` | 證型完整 Schema |
| `data/zhengsu/_schema.json` | 證素 Schema（含治法對應表）|
| `data/zhengxing/zhongqixiaxian.json` | 證型範例（較完整）|
| `data/zhengxing/shaoyinzheng.json` | 傷寒證型範例（含 transformation_types）|

---

## 八、用戶背景

- 中醫臨床執業者，43歲
- 熟悉 Obsidian，正在建立 TCM 知識管理系統
- 有證素辨證理論基礎
- 目標：將《中醫證候鑑別診斷學》483 個證候數位化

---

## 九、下一步行動

**建議在新對話中：**

1. 用戶上傳完整的證候文本檔
2. Claude 執行階段一分析：
   - 自動切分證型
   - 產出證型總覽表
   - 識別演變關係
   - 識別鑑別組
   - OCR 問題清單
3. 確認後進入批次處理

**提示詞範例：**
```
請先閱讀 docs/WORK_LOG.md 了解專案狀態，
然後分析我上傳的證候文本，執行階段一預處理。
```

---

## 十、技術備註

### 現有 Web 架構
- 純前端（HTML + CSS + JS）
- 資料以 JSON 形式存放
- 部署於 GitHub Pages

### 資料流
```
Obsidian Markdown (含 YAML)
         ↓ md_to_json.py（待建立）
     JSON 檔案
         ↓
   Web App 讀取顯示
```

### 已有的 JS 功能
- `loadZhenghouIndex()` — 載入索引
- `searchZhenghou()` — 搜尋證候
- `filterByLocation()` / `filterByNature()` — 篩選
- `showZhenghouDetail()` — 顯示詳情彈窗
- `renderEvolutionGroups()` — 渲染演變圖譜
- `renderComparisonPairs()` — 渲染類證對照

---

*此文件由 Claude 生成，用於跨對話延續工作進度*

---

## 十一、2025-12-05 更新

### 已完成工作

1. **證候文本批次轉換**
   - 56 個證型全部轉換為標準 JSON 格式
   - 位置：`data/zhengxing/*.json`
   - 自動提取：臨床表現、病機、症狀（主症/次症/舌脈）

2. **索引檔案建立**
   - `data/indexes/symptom_index.json` — 535 個症狀關鍵詞
   - `data/indexes/evolution_graph.json` — 56 節點, 21 邊
   - `data/indexes/differentiation_matrix.json` — 51 個證型鑑別資料

3. **腳本工具**
   - `scripts/analyze_zhenghou.py` — 預處理分析
   - `scripts/convert_zhenghou.py` — 批次轉換
   - `scripts/build_indexes.py` — 索引建立

### 資料完整度

| 欄位 | 完成率 |
|------|--------|
| id, name, category | 100% |
| symptoms (主症/次症/舌脈) | 100% |
| clinical_manifestations | 100% |
| zhengsu_composition | 100% (自動推斷) |
| severity | 100% (自動推斷) |
| pathogenesis | ~60% |
| differential_patterns | 91% |
| literature | 100% |

### 下一步

- [ ] 前端功能開發（Claude Code）
- [ ] 演變圖譜視覺化
- [ ] 並列對比功能
- [ ] 症狀反查介面
