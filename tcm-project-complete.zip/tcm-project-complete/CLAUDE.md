# TCM 中醫證候知識庫

> Claude Code 專案指引文件
> 最後更新：2025-12-05

## 專案概述

這是一個中醫證候知識庫專案，目標是：
1. **Obsidian Vault** — 個人學習與知識管理
2. **Web App** — 互動式證候查詢網站（GitHub Pages 部署）

### 核心功能規劃

| 功能 | 說明 | 狀態 |
|------|------|------|
| 證素篩選器 | 按病位/病性組合篩選證型 | ✅ 基礎版已有 |
| 並列對比 | 選擇多個證型並排比較 | 🔲 規劃中 |
| 互動式演變圖 | 可點擊展開的證型演變圖 | 🔲 規劃中 |
| 症狀反查 | 輸入症狀，顯示相關證型 | 🔲 規劃中 |

---

## 目錄結構

```
tcm-project/
├── CLAUDE.md              # ← 你正在讀的這個檔案
├── index.html             # Web App 主頁
├── css/style.css          # 樣式表
├── js/zhenghou.js         # 前端 JavaScript
├── data/
│   ├── zhengsu/           # 證素（55個）- 病位+病性的原子單位
│   ├── zhengxing/         # 證型（19個，待擴充至56個）
│   ├── zhenghou/          # 原始證候資料
│   │   └── syndromes/     
│   ├── herbs/             # 中藥
│   ├── formulas/          # 方劑
│   ├── symptoms/          # 症狀
│   ├── diseases/          # 病證
│   └── indexes/           # 索引檔案（待建立）
├── scripts/
│   ├── parse_zhenghou.py  # 證候解析腳本
│   └── analyze_zhenghou.py # 預處理分析腳本
├── docs/
│   ├── WORK_LOG.md        # 工作日誌（跨對話延續進度）
│   ├── PREPROCESSING_REPORT.md # 預處理分析報告
│   ├── STRUCTURE.md       # 資料結構說明
│   └── TODO.md            # 待辦事項
└── 中醫證候純文字檔.md      # 原始證候文本（56個證型）
```

---

## 資料結構

### 證素 Schema (`data/zhengsu/*.json`)

```json
{
  "id": "qi_xu",
  "name": "氣虛",
  "category": "病性",
  "subcategory": "氣機病變",
  "treatment": "補氣",
  "is_critical": false,
  "alias": ["氣弱", "中氣不足"],
  "description": "...",
  "related_symptoms": ["symptom_fali", "symptom_qiduan"]
}
```

### 證型 Schema (`data/zhengxing/*.json`)

```json
{
  "id": "piqixu",
  "name": "脾氣虛證",
  "category": "臟腑證候",
  "zhengsu_composition": {
    "location": ["pi"],
    "nature": ["qi_xu"]
  },
  "severity": 1,
  "symptoms": {
    "primary": ["納谷少馨", "神疲乏力"],
    "secondary": ["脘腹脹滿", "大便溏洩"],
    "tongue": "舌淡苔白",
    "pulse": "脈緩弱"
  },
  "pathogenesis": "脾失健運，水谷精微不能輸布",
  "treatment_principle": "健脾益氣",
  "recommended_formulas": ["sijunzi_tang", "shenlingbaizhu_san"],
  "evolved_from": ["qixu"],
  "can_evolve_to": ["zhongqixiaxian", "pixu_shizhi"],
  "differentiation": {
    "similar_patterns": ["weiqixu"],
    "key_differences": "..."
  }
}
```

### Severity 分級

| 等級 | 判定依據 | 代表證型 |
|------|----------|----------|
| 1 輕 | 基礎虛證 | 氣虛、血虛、陰虛、陽虛 |
| 2 中 | 進展證 | 氣陷、氣滯、血瘀 |
| 3 重 | 危重前驅 | 氣逆、氣閉、血脫 |
| 4 危 | 脫證 | 氣脫、亡陰、亡陽 |

---

## 開發規範

### 語言
- 繁體中文（所有文檔和數據）
- 變數/函數命名：英文或拼音

### 數據格式
- JSON，UTF-8 編碼，2 空格縮排
- ID 命名：小寫拼音，下劃線分隔（如 `qi_xu`, `zhong_qi_xia_xian`）

### 前端技術棧
- 純前端（HTML + CSS + JS）
- 無框架依賴，可直接 GitHub Pages 部署
- 圖表考慮：D3.js 或 Cytoscape.js（演變圖譜）

### Python 環境
- Python 3.10+
- 無特殊套件依賴

---

## 當前進度

### 已完成
- [x] 證素資料庫（55個）
- [x] 基礎證型示例（19個）
- [x] 原始證候文本分析（56個證型識別完成）
- [x] 預處理報告生成

### 進行中
- [ ] 批次轉換證候文本為 JSON
- [ ] 補充證素組合對應

### 待開始
- [ ] 索引檔案建立
- [ ] Web App 功能開發

---

## 常用指令

```bash
# 分析證候文本
python scripts/analyze_zhenghou.py

# 查看證型統計
jq 'keys | length' data/zhengxing/*.json

# 驗證 JSON 格式
python -m json.tool data/zhengxing/piqixu.json
```

---

## 重要參考檔案

| 檔案 | 說明 |
|------|------|
| `docs/WORK_LOG.md` | 完整工作日誌，含證素系統設計 |
| `docs/PREPROCESSING_REPORT.md` | 證候文本分析報告 |
| `data/zhengxing/_schema_extended.json` | 證型完整 Schema |
| `data/zhengsu/_schema.json` | 證素 Schema |
| `data/analysis_result.json` | 預處理分析結果 |

---

## 用戶背景

- 中醫臨床執業者
- 熟悉 Obsidian，正在建立 TCM 知識管理系統
- 有證素辨證理論基礎
- 目標：將《中醫證候鑑別診斷學》483 個證候數位化

---

## 與 Claude Chat 的分工

| 任務類型 | 建議使用 |
|----------|----------|
| 資料結構設計、證候分析 | Claude Chat |
| 批次腳本執行、程式碼撰寫 | Claude Code |
| 前端開發、CSS 調整 | Claude Code |
| 概念討論、流程規劃 | Claude Chat |

---

*此檔案供 Claude Code 啟動時自動讀取*
